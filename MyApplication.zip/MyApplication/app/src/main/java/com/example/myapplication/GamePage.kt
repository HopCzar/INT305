package com.example.myapplication

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageButton

class GamePage : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_game_page)
        val buttonClick = findViewById<ImageButton>(R.id.catanButton)
        buttonClick.setOnClickListener {
            val intent = Intent(this, Catan::class.java)
            startActivity(intent)
        }
        val buttonClicktwo = findViewById<ImageButton>(R.id.clueButton)
        buttonClicktwo.setOnClickListener {
            val intent = Intent(this, Clue::class.java)
            startActivity(intent)
        }
    }
}